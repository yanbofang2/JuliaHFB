# NaiveHF.jl
Simple Hubbard GHF implementation for my Julia tutorial
